1.Team 60  Yuyao Gao   Li Sun

2. Yuyao Gao: OO Design model, Tests, Implementation
   Li Sun: Use cases, traceability matrix, Implementation

3. File:
	menu.h  menu.cpp
	action.h  action.cpp
	mainwindow.h  mainwindow.cpp  mainwindow.ui
	Oasis_Pro.pro
	main.cpp                      

4. Test Scenarios:
	1.Power and "Ending A Session"  pass
	2.Battery level and low warnings  pass
	3.Selecting a session  pass
	4.Connection test   pass
	5.Intensity   pass
	6.Record    pass
	7.Replay	pass
	8.support different users  fail                 